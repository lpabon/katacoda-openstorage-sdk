# OSD Sanity Tester

This library provides a simple way to ensure that a OSD plugin conforms to
the OpenStorage specification.

Please see [osd-sanity](https://github.com/libopenstorage/openstorage/tree/master/cmd/osd-sanity)
