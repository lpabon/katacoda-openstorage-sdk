# NodeJS gRPC Client Library

## Build

Type `make`.

Requires `npm`

