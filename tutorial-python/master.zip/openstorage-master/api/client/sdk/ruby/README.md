# Ruby gRPC Client Library

## Build

Type `make`.

Requires `grpc` and `grpc-tools` gems. To install type:

```
$ gem install grpc
$ gem install grpc-tools
```

