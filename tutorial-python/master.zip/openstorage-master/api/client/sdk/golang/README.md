# Golang gRPC Client Library

The file is located in `api/api.pb.go`. Just import `github.com/libopenstorage/openstorage/api` to get access to the
client functions.

